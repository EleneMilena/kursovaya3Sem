package ru.makridina.kursovaya.service;

public interface GetRoleService {
    String getRoleCurrentUser();
}
