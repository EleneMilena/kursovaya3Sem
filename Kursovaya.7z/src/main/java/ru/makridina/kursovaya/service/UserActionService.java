package ru.makridina.kursovaya.service;

public interface UserActionService {
    void setUserAction(String userAction);
}
