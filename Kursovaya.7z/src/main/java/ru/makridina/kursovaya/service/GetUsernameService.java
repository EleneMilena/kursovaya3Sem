package ru.makridina.kursovaya.service;

public interface GetUsernameService {
    String getusername();
}
